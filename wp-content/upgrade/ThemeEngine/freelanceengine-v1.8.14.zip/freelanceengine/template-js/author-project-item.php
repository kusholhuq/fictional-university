<script type="text/template" id="employer-project-item">
    <li class="project-item">
        <div class="name-history">
            <span><a href="{{= permalink }}"> {{= post_title}} aaaaaaaaaaa</a></span><br>
            {{status_hiring}}
            <div class="clearfix"></div>
        </div>
        <ul class="info-history">
            <li> <span> 11 mins ago </span></li>
            <li> <span> 100 </span>$ </li>
        </ul>
    </li>
</script>
(function($){
	console.log('fre_social login');
})(jQuery);
<?php
/*
Plugin Name: AppEngine
Plugin URI: www.enginethemes.com
Description: Easy implement a front form, and publish a web application
Version: 1.2
Author: Engine Themes team
Author URI: www.enginethemes.com
License: GPL2
*/
if (!defined('USE_SOCIAL')) define('USE_SOCIAL', 1);
require_once dirname( __FILE__ ).'/bootstrap.php';
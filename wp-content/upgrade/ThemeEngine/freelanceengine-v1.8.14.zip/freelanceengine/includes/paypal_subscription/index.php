<?php
require_once dirname(__FILE__) . '/functions.php';
require_once dirname(__FILE__) . '/verify_response.php';
require_once dirname(__FILE__) . '/init.php';
require_once dirname(__FILE__) . '/ae_paypal_subscription.php';
require_once dirname(__FILE__) . '/debug.php';
require_once dirname(__FILE__) . '/settings.php';
require_once dirname(__FILE__) . '/front.php';
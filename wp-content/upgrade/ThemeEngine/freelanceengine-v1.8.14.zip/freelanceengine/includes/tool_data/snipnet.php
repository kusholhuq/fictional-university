<?php

wp_create_user_request();
wp_comments_personal_data_exporter();
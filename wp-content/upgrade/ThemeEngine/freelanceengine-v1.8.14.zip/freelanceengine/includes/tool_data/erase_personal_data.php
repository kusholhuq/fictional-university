<?php

//wp-privacy-erase-personal-data